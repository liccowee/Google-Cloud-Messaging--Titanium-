
Ti.UI.createWindow().open();
var push = require('PushNotification');
push.pushNotification();
